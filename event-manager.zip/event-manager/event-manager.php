<?php
/**
 * Plugin Name: Event Manager
 * Description: Zarządzanie wydarzeniami z rejestracją uczestników.
 * Version: 1.0.0
 * Author: Radek
 */

if ( ! defined( 'ABSPATH' ) ) {
    exit;
}

define( 'EM_PLUGIN_DIR', plugin_dir_path( __FILE__ ) );
define( 'EM_PLUGIN_URL', plugin_dir_url( __FILE__ ) );

require_once EM_PLUGIN_DIR . 'includes/cpt-registration.php';
require_once EM_PLUGIN_DIR . 'includes/acf-fields.php';
require_once EM_PLUGIN_DIR . 'includes/ajax-handlers.php';

function em_enqueue_assets() {
    if ( ! is_singular( 'event' ) ) {
        return;
    }

    wp_enqueue_script( 'em-tailwind-play', 'https://cdn.jsdelivr.net/npm/@tailwindcss/browser@4', [], '4.0.0', false );
    wp_enqueue_style( 'em-style', EM_PLUGIN_URL . 'assets/css/style.css', [], '1.3.4' );
    wp_enqueue_script( 'em-register', EM_PLUGIN_URL . 'assets/js/event-register.js', [], '1.3.4', true );

    wp_localize_script(
        'em-register',
        'EventManagerData',
        [
            'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
            'nonce'    => wp_create_nonce( 'em_register_event' ),
            'messages' => [
                'genericError' => __( 'Coś poszło nie tak. Spróbuj ponownie.', 'event-manager' ),
            ],
        ]
    );
}
add_action( 'wp_enqueue_scripts', 'em_enqueue_assets' );

function em_filter_single_template( $template ) {
    if ( is_singular( 'event' ) ) {
        $plugin_template = EM_PLUGIN_DIR . 'templates/single-event.php';
        if ( file_exists( $plugin_template ) ) {
            return $plugin_template;
        }
    }
    return $template;
}
add_filter( 'single_template', 'em_filter_single_template' );

function em_activate() {
    em_register_event_cpt();
    em_register_city_taxonomy();
    flush_rewrite_rules();
}
register_activation_hook( __FILE__, 'em_activate' );

function em_deactivate() {
    flush_rewrite_rules();
}
register_deactivation_hook( __FILE__, 'em_deactivate' );
